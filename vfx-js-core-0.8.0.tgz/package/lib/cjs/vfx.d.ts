import { type VFXOpts, type VFXProps } from "./types.js";
/**
 * The main interface of VFX-JS.
 */
export declare class VFX {
    #private;
    /**
     * Creates VFX instance and start playing immediately.
     */
    constructor(options?: VFXOpts);
    /**
     * Register an element to track the position and render visual effects in the area.
     */
    add(element: HTMLElement, opts: VFXProps): Promise<void>;
    /**
     * Remove the element from VFX and stop rendering the shader.
     */
    remove(element: HTMLElement): void;
    /**
     * Update the texture for the given element.
     *
     * If the element is an HTMLImageElemnt or HTMLVideoElement, VFX-JS does nothing.
     * Otherwise, VFX-JS captures a new snapshot of the DOM tree under the elemnt and udpate the WebGL texture with it.
     *
     * This is useful to apply effects to eleents whose contents change dynamically (e.g. input, textare etc).
     */
    update(element: HTMLElement): Promise<void>;
    /**
     * Start rendering VFX.
     */
    play(): void;
    /**
     * Stop rendering VFX.
     * You can restart rendering by calling `VFX.play()` later.
     */
    stop(): void;
    /**
     * Render the whole scene once, manually.
     * This is useful when you want to control the rendering timings manually by combining with `autoplay: false`.
     */
    render(): void;
    /**
     * Destroy VFX and stop rendering.
     */
    destroy(): void;
}
