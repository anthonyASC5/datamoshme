import { type Margin, type Rect } from "./rect.js";
import type { VFXElementIntersection, VFXOptsInner, VFXProps } from "./types";
/**
 * @internal
 */
export declare class VFXPlayer {
    #private;
    constructor(opts: VFXOptsInner, canvas: HTMLCanvasElement);
    destroy(): void;
    addElement(element: HTMLElement, opts?: VFXProps): Promise<void>;
    removeElement(element: HTMLElement): void;
    updateTextElement(element: HTMLElement): Promise<void>;
    updateCanvasElement(element: HTMLCanvasElement): void;
    isPlaying(): boolean;
    play(): void;
    stop(): void;
    render(): void;
}
/**
 * Returns if the given rects intersect.
 * It returns true when the rects are adjacent (= intersection ratio is 0).
 */
export declare function isRectInViewport(viewport: Rect, rect: Rect): boolean;
export declare function checkIntersection(viewport: Rect, rect: Rect, intersection: number, threshold: number): boolean;
export declare function parseOverflowOpts(overflow: VFXProps["overflow"]): [isFullScreen: boolean, Margin];
export declare function parseIntersectionOpts(intersectionOpts: VFXProps["intersection"]): VFXElementIntersection;
