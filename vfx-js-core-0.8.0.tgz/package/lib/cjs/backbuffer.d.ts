import * as THREE from "three";
import { type GLRect } from "./gl-rect";
/**
 * A class to manage initialization and double-buffring of the backbuffer.
 * @internal
 */
export declare class Backbuffer {
    #private;
    constructor(width: number, height: number, pixelRatio: number);
    get texture(): THREE.Texture;
    get target(): THREE.WebGLRenderTarget;
    /**
     * Resize textuers if necessary.
     * @param width - logical width of the backbuffer
     * @param height - logical height of the backbuffer
     */
    resize(width: number, height: number): void;
    /**
     * Swap double buffers for the backbuffer.
     * This should always be called right after the rendering.
     */
    swap(): void;
    getViewport(): GLRect;
}
