import * as THREE from "three";
import type { GLRect } from "./gl-rect.js";
export declare class CopyPass {
    #private;
    constructor();
    get uniforms(): {
        [name: string]: THREE.IUniform<any>;
    };
    setUniforms(tex: THREE.Texture, pixelRatio: number, xywh: GLRect): void;
    get scene(): THREE.Scene;
}
