/**
 * @internal
 */
type Tetra = {
    left: number;
    right: number;
    top: number;
    bottom: number;
};
/**
 * top-left origin rect.
 * Subset of DOMRect, which is returned by `HTMLElement.getBoundingClientRect()`.
 * @internal
 */
export type Rect = Tetra & {
    readonly __brand: unique symbol;
};
export declare const RECT_ZERO: Rect;
/**
 * @internal
 */
export type Margin = Tetra & {
    readonly __brand: unique symbol;
};
/**
 * Values for margin, padding, overflow etc.
 */
export type MarginOpts = number | [top: number, right: number, bottom: number, left: number] | {
    top?: number;
    right?: number;
    bottom?: number;
    left?: number;
};
export declare function createMargin(r: MarginOpts): Margin;
export declare const MARGIN_ZERO: Margin;
/**
 * Values to determine a rectangle area for margin, padding etc.
 */
export type RectOpts = MarginOpts;
export declare function createRect(r: RectOpts): Rect;
export declare function toRect(r: DOMRect): Rect;
export declare function growRect(a: Rect, b: Margin): Rect;
export declare function shrinkRect(a: Rect, b: Margin): Rect;
/**
 * Calculate the ratio of the intersection between two Rect objects.
 * It returns a number between 0 and 1.
 */
export declare function getIntersection(container: Rect, target: Rect): number;
export {};
