import * as THREE from "three";
import { Backbuffer } from "./backbuffer.js";
import type { GLRect } from "./gl-rect.js";
import type { VFXUniformValue, VFXUniforms } from "./types.js";
export declare class PostEffectPass {
    #private;
    constructor(fragmentShader: string, uniforms?: VFXUniforms, useBackbuffer?: boolean);
    get uniforms(): {
        [name: string]: THREE.IUniform<any>;
    };
    setUniforms(tex: THREE.Texture, pixelRatio: number, xywh: GLRect, time: number, mouseX: number, mouseY: number): void;
    updateCustomUniforms(uniformGenerators?: {
        [name: string]: () => VFXUniformValue;
    }): void;
    initializeBackbuffer(width: number, height: number, pixelRatio: number): void;
    resizeBackbuffer(width: number, height: number): void;
    get backbuffer(): Backbuffer | undefined;
    get scene(): THREE.Scene;
}
